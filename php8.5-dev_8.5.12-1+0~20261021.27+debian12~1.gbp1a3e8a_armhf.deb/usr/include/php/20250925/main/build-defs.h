/*
   +----------------------------------------------------------------------+
   | Copyright (c) The PHP Group                                          |
   +----------------------------------------------------------------------+
   | This source file is subject to version 3.01 of the PHP license,      |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | https://www.php.net/license/3_01.txt                                 |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Author: Stig Sæther Bakken <ssb@php.net>                             |
   +----------------------------------------------------------------------+
*/

#define CONFIGURE_COMMAND " '../configure'  '--includedir=${prefix}/include' '--mandir=${prefix}/share/man' '--infodir=${prefix}/share/info' '--disable-option-checking' '--disable-silent-rules' '--libdir=${prefix}/lib/arm-linux-gnueabihf' '--libexecdir=${prefix}/lib/arm-linux-gnueabihf' '--disable-maintainer-mode' '--disable-dependency-tracking' '--prefix=/usr' '--enable-cli' '--disable-cgi' '--disable-phpdbg' '--with-config-file-path=/etc/php/8.5/cli' '--with-config-file-scan-dir=/etc/php/8.5/cli/conf.d' '--build=arm-linux-gnueabihf' '--host=arm-linux-gnueabihf' '--config-cache' '--cache-file=/tmp/buildd/nonexistent/config.cache' '--libdir=\${prefix}/lib/php' '--libexecdir=\${prefix}/lib/php' '--datadir=\${prefix}/share/php/8.5' '--program-suffix=8.5' '--sysconfdir=/etc' '--localstatedir=/var' '--mandir=/usr/share/man' '--disable-all' '--disable-debug' '--disable-rpath' '--disable-static' '--disable-dtrace' '--with-pic' '--with-layout=GNU' '--without-pear' '--enable-filter' '--with-openssl' '--with-password-argon2=/usr' '--with-external-pcre' '--enable-hash' '--with-mhash=/usr' '--with-libxml' '--enable-session' '--with-sodium' '--with-system-tzdata' '--with-zlib=/usr' '--with-zlib-dir=/usr' '--without-pcre-jit' '--enable-pcntl' '--with-libedit=shared,/usr' 'build_alias=arm-linux-gnueabihf' 'host_alias=arm-linux-gnueabihf' 'CFLAGS=-g -O2 -fstack-protector-strong -Wformat -Werror=format-security -Wall -pedantic -fsigned-char -fno-strict-aliasing -D_LARGEFILE_SOURCE -D_FILE_OFFSET_BITS=64 -DTELEMETRY_HOST='"
#define PHP_PROG_SENDMAIL	"/usr/sbin/sendmail"
#define PEAR_INSTALLDIR         "/usr/share/php"
#define PHP_INCLUDE_PATH	".:/usr/share/php"
#define PHP_EXTENSION_DIR       "/usr/lib/php/20250925"
#define PHP_PREFIX              "/usr"
#define PHP_BINDIR              "/usr/bin"
#define PHP_SBINDIR             "/usr/sbin"
#define PHP_MANDIR              "/usr/share/man"
#define PHP_LIBDIR              "/usr/lib/php"
#define PHP_DATADIR             "/usr/share/php/8.5"
#define PHP_SYSCONFDIR          "/etc"
#define PHP_LOCALSTATEDIR       "/var"
#define PHP_CONFIG_FILE_PATH    "/etc/php/8.5/cli"
#define PHP_CONFIG_FILE_SCAN_DIR    "/etc/php/8.5/cli/conf.d"
#define PHP_SHLIB_SUFFIX        "so"
#define PHP_SHLIB_EXT_PREFIX    ""
